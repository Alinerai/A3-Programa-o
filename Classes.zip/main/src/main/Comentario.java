
package main;

class Comentario {
    public String estabelecimento;
    public String usuario;
    public String comentario;

    public Comentario(String estabelecimento, String usuario, String comentario) {
        this.estabelecimento = estabelecimento;
        this.usuario = usuario;
        this.comentario = comentario;
         System.out.println("\nComentar sobre " +this.estabelecimento);
         System.out.println("Adicione um comentário com base em sua experiência com o(a) " + this.estabelecimento);
         System.out.println(this.usuario + ": "+ this.comentario);
    }
    
}
