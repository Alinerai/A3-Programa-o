
package main;


class Estabelecimento {
    
    public String nomeEmpresa;
    private String cnpj;
    public String categoria;
    public String endereco;
    public int telefone;
    public String horarioFuncionamento;
    public String diasFuncionamento;

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public Estabelecimento(String nomeEmpresa, String cnpj, String categoria, String endereco, int telefone, String horarioFuncionamento, String diasFuncionamento) {
        this.nomeEmpresa = nomeEmpresa;
        this.cnpj = cnpj;
        this.categoria = categoria;
        this.endereco = endereco;
        this.telefone = telefone;
        this.horarioFuncionamento = horarioFuncionamento;
        this.diasFuncionamento = diasFuncionamento;
        System.out.println("\nAdicionar Estabelecimento");
         System.out.println("Nome: " + this.nomeEmpresa);
         System.out.println("CNPJ: " + this.cnpj);
         System.out.println("Categoria: " + this.categoria);
         System.out.println("Endereço: "+ this.endereco);
         System.out.println("Telefone para contato: " + this.telefone);
         System.out.println("Horário de Funcionamento: " + this.horarioFuncionamento);
         System.out.println("Dias de Funcionamento: " + this.diasFuncionamento);
         
    }
   
}
