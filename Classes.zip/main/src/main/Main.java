
package main;


public class Main {

    public static void main(String[] args) {
        
Usuario usuario1 = new Usuario("Aline", "raiane@gmail", "11122");

usuario1.LOGIN("raiane@gmail", "11122");   

Estabelecimento estabelecimento1 = new Estabelecimento("ArtPrint", "112245776-65", "loja", "Rua 1, n° 234 Bairro Vila", 998745432, "Das 8:00 às 17:00", "Segunda a sexta");

Comentario comentario1 = new Comentario("ArtPrint", "Aline", "Um otimo estabelecimento, com bom atendimento");

Avaliacao avaliacao1 = new Avaliacao("ArtPrint", "Aline", 4);


    }   
}

