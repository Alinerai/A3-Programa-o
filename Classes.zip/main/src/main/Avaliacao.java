
package main;

public class Avaliacao {
   public String estabelecimento;
   public String usuario;
   public int avaliacao;

    public Avaliacao(String estabelecimento, String usuario,int avaliacao) {
        this.estabelecimento = estabelecimento;
        this.usuario= usuario;
        this.avaliacao = avaliacao;
        System.out.println("\nAvalie o(a) " +this.estabelecimento);
        System.out.println("Adicione sua nota entre 1 a 5, com base em sua experiência com o(a) " + this.estabelecimento);
        System.out.println(this.usuario +":"+ this.avaliacao);
    }
   
}
