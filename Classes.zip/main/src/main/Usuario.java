
package main;


class Usuario {
    
    
    public String nome;
    public String email;
    private String senha;

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public Usuario(String nome, String email, String senha) {
        this.nome = nome;
        this.email = email;
        this.senha = senha;
        System.out.println("Cadastrar Usuário");
        System.out.println("Digigte seu nome:  "+ this.nome);
        System.out.println("Digite seu E-mail: " + this.email);
        System.out.println("Crie uma senha de 5 caracteres: " + this.senha);
    }

    public void LOGIN(String email, String senha) {
        this.email = email;
        this.senha = senha;
        System.out.println("\nLOGIN");
        System.out.println("Email: " + this.email);
        System.out.println("Senha: " + this.senha);
        System.out.println("ENTRAR");
    }
    
   
}
